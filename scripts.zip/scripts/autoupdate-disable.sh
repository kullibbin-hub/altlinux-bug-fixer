#!/bin/sh
echo -e  '\e[33m
Отключение автообновления
\e[0m'
gsettings set org.gnome.software download-updates false
echo -e '\e[33m 
Автообновление отключено, это ускорило запуск центра приложений, 
но уведомления об их наличии будут приходить все равно!
\e[0m'
