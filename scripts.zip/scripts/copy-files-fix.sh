#!/bin/sh
echo -e  '\e[33m
Настройка адекватного поведения индикатора копирования nautilus
\e[0m'
DIRTY_FILE="/etc/sysctl.d/90-dirty.conf"

echo "→ Applying and saving vm.dirty settings..."

# 64 МБ и 16 МБ
DIRTY_BYTES=$((64 * 1024 * 1024))
DIRTY_BG_BYTES=$((16 * 1024 * 1024))

echo "→ Writing persistent config to $DIRTY_FILE
"
sudo bash -c "cat > $DIRTY_FILE" <<EOF
vm.dirty_bytes = $DIRTY_BYTES
vm.dirty_background_bytes = $DIRTY_BG_BYTES
EOF

echo "→ Applying values now..."
sudo sysctl -p "$DIRTY_FILE"

echo "✓ Done. Persistent settings active!"
echo "
Check after reboot:"
echo " sudo sysctl vm.dirty_bytes vm.dirty_background_bytes
"
echo -e  '\e[33m
Готово.
\e[0m'

