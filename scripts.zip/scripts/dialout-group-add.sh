#!/bin/sh
echo -e  '\e[33m
Добавление текущего пользователя в группу dialout
\e[0m'

sudo usermod -a -G dialout $USER
 
echo -e  '\e[33m
Готово. Для применения изменений надо
перезагрузить компьютер.
\e[0m'
