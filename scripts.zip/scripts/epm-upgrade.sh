#!/bin/sh
echo -e  '\e[33m
Обновление программ в epm play
\e[0m'

sudo epm upgrade "https://download.etersoft.ru/pub/Korinf/x86_64/ALTLinux/p11/eepm-*.noarch.rpm"

echo -e  '\e[33m
Готово.
\e[0m'
