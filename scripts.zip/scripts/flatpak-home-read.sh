#!/bin/sh
echo -e  '\e[33m
Разрешение приложениям Flatpak на доступ к домашнему каталогу
\e[0m'
flatpak override --user --filesystem=home
echo -e  '\e[33m
Готово, теперь drag-n-drop с рабочего стола работает.
\e[0m'

