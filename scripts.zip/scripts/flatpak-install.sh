#!/bin/sh
echo -e  '\e[33m
Установка flatpak и необходимых компонентов.
\e[0m'

sudo apt-get update
sudo apt-get install -y flatpak firsttime-flatpak-mask-openh264 flatpak-fix-openh264+stplr-test-flatpak-fix-openh264 flatpak-repo-flathub

echo -e  '\e[33m
Готово.
\e[0m'

