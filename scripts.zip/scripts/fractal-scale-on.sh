#!/bin/sh
echo -e  '\e[33m
Включение дробного масштабирования дисплея
\e[0m'

gsettings set org.gnome.mutter experimental-features "['scale-monitor-framebuffer']"

echo -e  '\e[33m
Готово. После перезагрузки появится различный коэффициент
масштабирования в настройках Gnome - Дисплеи.
\e[0m'
