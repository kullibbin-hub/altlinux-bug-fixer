#!/bin/sh
echo -e  '\e[33m
Фикс ложного включения gsconnect
\e[0m'
AUTOSTART_DIR="$HOME/.config/autostart"
SCRIPT_DIR="$HOME/.local/bin"

SCRIPT_FILE="$SCRIPT_DIR/kill-daemonjs.sh"
DESKTOP_FILE="$AUTOSTART_DIR/kill-daemonjs.desktop"

mkdir -p "$SCRIPT_DIR"
mkdir -p "$AUTOSTART_DIR"

cat > "$SCRIPT_FILE" << 'EOF'
#!/bin/sh
sleep 10
pkill -f "/usr/share/gnome-shell/extensions/gsconnect@andyholmes.github.io/service/daemon.js"
EOF

chmod +x "$SCRIPT_FILE"

cat > "$DESKTOP_FILE" << EOF
[Desktop Entry]
Type=Application
Name=Kill daemon.js
Exec=$SCRIPT_FILE
X-GNOME-Autostart-enabled=true
NoDisplay=true
EOF

echo -e  "\e[33m
Автозагрузка создана: $DESKTOP_FILE
Теперь gsconnect работает адекватно
\e[0m"
