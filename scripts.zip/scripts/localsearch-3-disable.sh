#!/bin/sh
echo -e  '\e[33m
Отключение сканирования содержимого файлов для поиска. 
Иногда эта служба localsearch-3 глючит с midi файлами 
и тормозит выключение компьютера.
\e[0m'

systemctl --user mask localsearch-3
systemctl --user stop localsearch-3

echo -e  '\e[33m
Готово.
\e[0m'

