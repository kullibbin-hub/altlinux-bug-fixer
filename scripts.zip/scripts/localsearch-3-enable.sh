#!/bin/sh
echo -e  '\e[33m
Включение службы индексации содержимого файлов
localsearch-3
\e[0m'

systemctl --user unmask localsearch-3
systemctl --user start localsearch-3

echo -e  '\e[33m
Готово.
\e[0m'

