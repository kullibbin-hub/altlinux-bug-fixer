#!/bin/sh
echo -e  '\e[33m
Настройка nautilus
\e[0m'

gsettings set org.gtk.gtk4.Settings.FileChooser sort-directories-first true
gsettings set org.gnome.nautilus.preferences show-create-link true
gsettings set org.gnome.nautilus.preferences show-delete-permanently true
gsettings set org.gnome.nautilus.icon-view captions "['size', 'date_modified', 'none']"

echo 'Включены опции: папки перед файлами, создание ссылок,
удаление помимо корзины, и доп. информация о файлах в режиме значков.
Добавление опции - открыть от имени администратора (nautilus-admin)
'
echo -e  '\e[33m
Готово.
\e[0m'

