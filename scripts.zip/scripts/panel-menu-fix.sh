#!/bin/sh
echo -e  '\e[33m
Добавление в контекстное меню нижней панели доп. программ
\e[0m'

gsettings set org.gnome.shell.extensions.dash-to-panel context-menu-entries '[{"title":"Terminal","cmd":"kgx"},{"title":"System monitor","cmd":"resources"},{"title":"Files","cmd":"nautilus"},{"title":"Extensions","cmd":"extension-manager"},{"title":"Тюнер","cmd":"tuner"},{"title":"Очистка кэша приложений","cmd":"spruce"},{"title":"Альтератор - центр управления","cmd":"acc"}]'
gsettings set org.gnome.shell.extensions.dash-to-panel overview-click-to-exit true
gsettings set org.gnome.shell.extensions.dash-to-panel secondarymenu-contains-showdetails true
gsettings set org.gnome.shell.extensions.arcmenu menu-height 600

echo 'Теперь меню имеет вид:

Терминал
Системный монитор
Файлы
Расширения
Тюнер
Очистка кэша приложений
Альтератор - центр управления
'

echo -e  '\e[33m
Готово.
\e[0m'
