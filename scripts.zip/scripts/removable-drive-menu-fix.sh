#!/bin/sh
echo -e  '\e[33m
Фикс появления фантомных устройств в индикаторе флешек
\e[0m'

sudo rm -f /etc/polkit-1/rules.d/49-no-usb-mount-gdm.rules
set -e

EXT_DIR="/usr/share/gnome-shell/extensions"
EXT_NAME="drive-menu@gnome-shell-extensions.gcampax.github.com"
FILE="extension.js"
TARGET="$EXT_DIR/$EXT_NAME/$FILE"
BACKUP="$TARGET.bak"

# Оригинальный размер файла, который можно патчить
ORIGINAL_SIZE=6197

echo "Проверяю наличие системного расширения..."

if [ ! -f "$TARGET" ]; then
    echo "Ошибка: файл $TARGET не найден."
    exit 1
fi

CURRENT_SIZE=$(stat -c%s "$TARGET")

echo "Оригинальный размер: $ORIGINAL_SIZE"
echo "Текущий размер:      $CURRENT_SIZE"

# Проверка размера
if [ "$CURRENT_SIZE" != "$ORIGINAL_SIZE" ]; then
    echo "Размер файла изменился. Патч НЕ применяется."
    :
else
    # Проверка, что патч ещё не применён
    if grep -q "this._mounts.some" "$TARGET"; then
        echo "Патч уже применён. Ничего делать не нужно."
        echo "Продолжаю выполнение скрипта."
        :
    else
        echo "Размер совпадает. Файл оригинальный. Создаю резервную копию: $BACKUP"
        sudo cp "$TARGET" "$BACKUP"

        echo "Применяю патч..."

        sudo patch "$TARGET" << 'EOF'
@@ -178,6 +178,9 @@
     }
 
     _addMount(mount) {
+        if (this._mounts.some(item => item.mount === mount))
+            return;
+
         let item = new MountMenuItem(mount);
         this._mounts.unshift(item);
         this.menu.addMenuItem(item, 0);
EOF

        echo "Патч успешно применён."
        echo "Очищаю кэш GNOME Shell..."
        rm -rf ~/.cache/gnome-shell/*
    fi
fi

echo -e  '\e[33m
Готово.
\e[0m'


