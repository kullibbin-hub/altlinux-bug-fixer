#!/bin/sh
echo -e  '\e[33m
Установка epm и затем f3d через epm play
\e[0m'

sudo apt-get update
sudo apt-get install -y eepm

sudo epm install task/409890/f3d

echo -e  '\e[33m
Готово.
\e[0m'


