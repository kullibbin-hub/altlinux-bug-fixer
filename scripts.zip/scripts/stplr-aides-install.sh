#!/bin/sh
echo -e  '\e[33m
Установка stplr и репозитория aides, а также
подключение его к центру приложений.

\e[0m'

sudo apt-get update
sudo apt-get install -y stplr stplr-repo-aides gnome-software-plugin-stplr

echo -e  '\e[33m
Готово.
\e[0m'

