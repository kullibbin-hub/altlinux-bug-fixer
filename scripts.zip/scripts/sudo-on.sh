#!/bin/sh
echo -e  '\e[33m
Получение sudo
'
pkexec bash control sudowheel enabled

echo -e  '\e[33m
sudo получено.
\e[0m'
