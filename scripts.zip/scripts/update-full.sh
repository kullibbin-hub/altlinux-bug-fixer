#!/bin/sh
echo -e  '\e[33m
========== Обновление пакетов и системы из репозитория 
\e[0m'
sudo apt-get update && sudo apt-get -y dist-upgrade

echo -e  '\e[33m
========== Обновление ядра ============================
\e[0m'
sudo update-kernel -H -y

echo -e  '\e[33m
========== Обновление flatpak =========================
\e[0m'
flatpak update -y

echo -e  '\e[33m
========== Очистка ====================================
\e[0m'
sudo apt-get clean

echo -e  '\e[33m
Готово.
\e[0m'

