#!/bin/sh
echo -e  '\e[33m
========== Обновление пакетов и системы из репозитория 
\e[0m'
sudo apt-get update && sudo apt-get -y dist-upgrade

#echo -e  '\e[33m
#========== Обновление ядра ============================
#\e[0m'
#sudo update-kernel -H -y

echo -e  '\e[33m
========== Обновление epm, если он установлен =========
\e[0m'

if rpm -q eepm >/dev/null 2>&1; then
    echo "Выполняю обновление...
    "
    sudo epm upgrade "https://download.etersoft.ru/pub/Korinf/x86_64/ALTLinux/p11/eepm-*.noarch.rpm"
    sudo epm play --update all
else
    echo "eepm не установлен.
    "
fi

echo -e  '\e[33m
========== Обновление flatpak =========================
\e[0m'
flatpak update -y

echo -e  '\e[33m
========== Очистка ====================================
\e[0m'
sudo apt-get clean

echo -e  '\e[33m
Готово. Теперь желательно перезагрузить компьютер.
\e[0m'





